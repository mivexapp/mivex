<div align="center">

<img src="https://raw.githubusercontent.com/mivexapp/mivex/main/desktop/electron/installer/icon.png" alt="Mivex" width="112" height="112">

# 🎉 Mivex 1.0 — oficjalnie!

### *Gadaj ze swoją ekipą. Bez szumu.*

**Pierwsze pełne wydanie Mivexa** — na Windows, na Androida i w przeglądarce.<br>
Wczesny dostęp się skończył. Od dziś Mivex to **wersja 1.0**.

[![Windows](https://img.shields.io/badge/⬇_Windows-mivex--setup.exe-0078D4?style=for-the-badge&logo=windows&logoColor=white)](https://github.com/mivexapp/mivex/releases/download/v1.0.0/mivex-setup.exe)
[![Android](https://img.shields.io/badge/⬇_Android-mivex.apk-3DDC84?style=for-the-badge&logo=android&logoColor=white)](https://github.com/mivexapp/mivex/releases/download/v1.0.0/mivex.apk)
[![Web](https://img.shields.io/badge/🌐_Przeglądarka-mivex.com.pl-5446FF?style=for-the-badge)](https://mivex.com.pl)

</div>

---

## 👋 Dzięki, że jesteście

Mivex zaczął się jako mały komunikator dla znajomych — z jedną zasadą: **rozmowy mają działać perfekcyjnie**. Przez cały wczesny dostęp dokładaliśmy kolejne kawałki: serwery, postacie AI, muzykę, sklep, aplikację na telefon. Każdy zgłoszony błąd i każdy pomysł od Was trafiał na listę.

**Wersja 1.0 to moment, w którym mówimy: Mivex jest gotowy.** Stabilny, szybki, bez reklam, w 10 językach — i z kodem aplikacji otwartym tutaj, na GitHubie.

---

## ✨ Najważniejsze w 1.0

> [!TIP]
> **TL;DR:** 💎 Mivex Platinum za złotówki (także **na zawsze**) · 🔔 powiadomienia push na Androidzie przy zamkniętej aplikacji · ⌨️ klawiatura już nie zasłania pisania · 🧊 koniec z zawieszaniem aplikacji · ✖️ zamykany odtwarzacz Mivex Music · 🏅 odznaka „Wspierający Mivex” · 🧑‍💻 kod aplikacji na GitHubie

---

### 💎 Mivex Platinum — teraz także za złotówki

Platinum możesz kupić kodem **paysafecard** — bez karty i bez konta bankowego.

| Plan | Cena | Na ile |
|---|:-:|---|
| 🌙 **Miesiąc** | **9,99 zł** | 30 dni |
| 🌗 **3 miesiące** | **19,99 zł** | 90 dni — taniej o ⅓ |
| ☀️ **Rok** | **49,00 zł** | 365 dni — najlepszy stosunek ceny |
| ♾️ **Na zawsze** | **75,00 zł** | **bez końca** — płacisz raz |

**Nowe w sklepie, w zakładce „Za złotówki”:**

| Przedmiot | Cena | Co dostajesz |
|---|:-:|---|
| 💠 **10 000 diamentów** | 9,99 zł | na ramki, odznaki i dodatki |
| 💠 **30 000 diamentów** | 24,99 zł | więcej za mniej |
| 💠 **80 000 diamentów** | 49,99 zł | pakiet dla kolekcjonerów |
| 👑 **Pakiet Legenda** | 19,99 zł | **5 ramek** + odznaka **Diamond Fan** + **5 000 💎** |

🏅 **Każdy zakup** daje nową odznakę **„Wspierający Mivex”** na profilu. Dziękujemy!

<details>
<summary><b>🧾 Jak działa płatność kodem PSC?</b></summary>

1. Wybierasz produkt i wpisujesz **16-cyfrowy kod paysafecard** (formatuje się sam: `1234-5678-…`).
2. Podajesz wartość kodu. Jeśli jest **wyższa niż cena**, Mivex Cię ostrzeże.
3. Dostajesz **e-mail z numerem płatności** (`MX-XXXX-XXXX`) i wszystkimi danymi — na wszelki wypadek.
4. Zespół Mivex sprawdza i przypisuje kod.
5. Po akceptacji produkt **nadaje się automatycznie**, a Ty dostajesz **powiadomienie** i **e-mail**.
6. Jeśli kod był wart więcej niż produkt, nadwyżka może wrócić do Ciebie **w diamentach** (1 zł = 1 000 💎).

> [!WARNING]
> **Nie wydawaj kodu**, dopóki płatność nie zostanie zaakceptowana — inaczej nie da się jej zrealizować.

🛡️ **Ochrona przed spamem:** jedna oczekująca płatność naraz, najwyżej 3 na dobę, a ten sam kod nie przejdzie drugi raz.

</details>

---

### 📱 Android — duża aktualizacja

| | Co się zmieniło |
|:-:|---|
| 🔔 | **Powiadomienia push przy zamkniętej aplikacji** — jak na Discordzie. Wiadomości prywatne, grupy, wzmianki **@** na serwerach i zaproszenia do znajomych. Dotknięcie otwiera od razu właściwą rozmowę. |
| 📢 | **Osobne kanały powiadomień** — *Wiadomości* i *Płatności*. Każdy możesz ustawić osobno w ustawieniach Androida. |
| ⌨️ | **Klawiatura nie zasłania pisania.** Pole wiadomości zostaje nad klawiaturą, a dolne zakładki się chowają — dokładnie tak, jak powinno być. |
| 🧊 | **Koniec z zawieszaniem.** Aplikacja nie „staje” już po zmianie sieci ani po powrocie z tła i nie trzeba jej resetować. |
| 🩹 | **Automatyczne podnoszenie się** — gdy Android zamknie silnik strony z braku pamięci, Mivex uruchamia ekran od nowa zamiast białego ekranu. |
| ⬆️ | **Baner aktualizacji** — gdy wyjdzie nowsza wersja, aplikacja sama Ci o tym powie. |

<details>
<summary><b>🔧 Szczegóły techniczne poprawek</b></summary>

- Każde zapytanie do serwera ma **limit czasu** (25 s, przy wysyłaniu plików 120 s, synchronizacja 15 s). Wcześniej zapytanie mogło czekać w nieskończoność po zmianie Wi-Fi ↔ LTE.
- **Strażnik synchronizacji** sprawdza co 5 s, czy wiadomości wciąż się odświeżają, i w razie potrzeby wznawia synchronizację.
- Po **ponad 20 minutach w tle** aplikacja odświeża się przy powrocie — chyba że trwa rozmowa głosowa albo wysyłanie pliku.
- W manifeście ustawione `adjustResize`, plus zapasowe dopasowanie układu do wysokości klawiatury.
- Obsługa `onRenderProcessGone` w `MainActivity` → `recreate()`.
- Nowa wtyczka natywna **MivexNative**: wersja aplikacji, wykrywanie Firebase, otwieranie linków w przeglądarce.
- `versionCode 2`, `versionName 1.0`.

</details>

---

### 🎵 Mivex Music

- ✖️ **Pasek muzyki i okienko teledysku mają przycisk zamknięcia.** Szczególnie wygodne na telefonie.
- Zamknięcie zatrzymuje odtwarzanie i czyści kolejkę — **pasek nie wraca** po przeładowaniu strony.

---

### 🛠️ Panel administracyjny

- Nowa sekcja **„Płatności”** z listą zamówień i nickami kupujących.
- **Autoryzacja w 3 krokach:** skopiuj kod → przypisz go do konta i wpisz prawdziwą wartość → zaakceptuj albo odrzuć z powodem.
- **Powiadomienie na żywo** o nowej płatności — na telefonie i w aplikacji na komputer — oraz licznik na ikonie panelu.
- Statystyki: oczekujące płatności i przychód z bieżącego miesiąca.
- Każde podejrzenie kodu jest zapisywane w dzienniku administratora.

---

### 🧑‍💻 Kod aplikacji na GitHubie

Od wersji 1.0 **kod aplikacji na Windows i Androida jest publiczny** w tym repozytorium, na licencji **MIT**.

- 🔍 Możesz sprawdzić, co dokładnie robi aplikacja na Twoim komputerze i telefonie.
- 🏗️ Możesz ją **zbudować sam** — instrukcja w [README](https://github.com/mivexapp/mivex#%EF%B8%8F-budowanie-ze-źródeł).
- 🤝 Możesz zgłaszać błędy w [Issues](https://github.com/mivexapp/mivex/issues) i wysyłać Pull Requesty.

Na stronie **mivex.com.pl**, obok przycisków pobierania, jest teraz przycisk **„Zobacz na GitHub”**.

---

### 🌐 Strona i reszta

- 🏷️ Strona główna pokazuje **„Mivex 1.0 · Oficjalne wydanie”**.
- 📧 E-maile o płatnościach w **języku odbiorcy** (10 języków).
- 🌍 Ponad **140 nowych tekstów** przetłumaczonych na wszystkie 10 języków.
- ⚡ Szybsze odpowiedzi serwera — powiadomienia wysyłają się w tle, już po odpowiedzi na wiadomość.

---

## ⬇️ Pobierz

| | Plik | System | Rozmiar |
|:-:|---|---|:-:|
| 🪟 | **[mivex-setup.exe](https://github.com/mivexapp/mivex/releases/download/v1.0.0/mivex-setup.exe)** | Windows 10 / 11, 64-bit | ~72 MB |
| 🤖 | **[mivex.apk](https://github.com/mivexapp/mivex/releases/download/v1.0.0/mivex.apk)** | Android 7.0 lub nowszy | ~6 MB |
| 🌐 | **[mivex.com.pl](https://mivex.com.pl)** | każda nowoczesna przeglądarka | — |

<details>
<summary><b>🪟 Instalacja na Windows</b></summary>

1. Pobierz `mivex-setup.exe` i uruchom.
2. Jeśli pojawi się **„System Windows ochronił komputer”** → **Więcej informacji** → **Uruchom mimo to**.
3. Wybierz język i folder → **Zainstaluj**.
4. Gotowe — Mivex uruchomi się sam.

Masz już starszą wersję? Po prostu zainstaluj nową w tym samym folderze — ustawienia i logowanie zostają.

</details>

<details>
<summary><b>🤖 Instalacja na Androidzie</b></summary>

1. Pobierz `mivex.apk` na telefon i otwórz.
2. Zezwól na instalację z tego źródła.
3. Zainstaluj — **na starej wersji**, nie trzeba jej usuwać.
4. Po uruchomieniu **zezwól na powiadomienia**.

</details>

---

## ⚠️ Znane ograniczenia

- 🔐 **Windows SmartScreen** ostrzega przed instalatorem, bo nie ma płatnego certyfikatu podpisu kodu. Plik jest zbudowany z kodu z tego repozytorium.
- 💳 **Saldo kodu PSC** nie jest sprawdzane automatycznie — paysafecard udostępnia to tylko firmom z umową. Wartość potwierdza ręcznie zespół Mivex.
- 🍎 **iPhone / macOS / Linux** — na razie bez osobnej aplikacji; Mivex działa w przeglądarce.

---

## 🏗️ Dla deweloperów

| | |
|---|---|
| **Windows** | Electron 33.4 · electron-builder 25 · własny instalator (portable) |
| **Android** | Capacitor 8.5 · Gradle 8.14 · AGP 8.13 · minSdk 24 · targetSdk 36 · JDK 21 |
| **Node.js** | 22 lub nowszy |

```bash
# Windows
cd desktop && npm ci && npm run dist

# Android (JAVA_HOME = JDK 21, ANDROID_HOME = Android SDK)
cd android && npm ci && npm run build
```

Pełna instrukcja, konfiguracja i własny klucz podpisu: **[README.md](https://github.com/mivexapp/mivex#readme)**.

---

<details>
<summary><b>🇬🇧 English summary</b></summary>

### Mivex 1.0 — official release 🎉

Early access is over — **Mivex is now 1.0** on Windows, Android and the web.

- 💎 **Mivex Platinum for PLN** via paysafecard: 9.99 zł / month, 19.99 zł / 3 months, 49.00 zł / year, **75.00 zł forever**. New diamond packs and the **Legend Bundle**. Every purchase grants the **Mivex Supporter** badge.
- 🔔 **Android push notifications while the app is closed** — DMs, groups, @mentions and friend requests; separate *Messages* and *Payments* channels.
- ⌨️ **The keyboard no longer covers the message box** on Android.
- 🧊 **No more freezes** — request timeouts, a sync watchdog, refresh after long background time and automatic recovery when Android kills the web renderer.
- ⬆️ **Update banner** for outdated apps.
- ✖️ **Closable Mivex Music player and video window.**
- 🛠️ New **Payments** section in the admin panel with live notifications.
- 🧑‍💻 **The Windows and Android app source code is now public** on GitHub under the MIT license.

**Downloads:** `mivex-setup.exe` (Windows 10/11, ~72 MB) · `mivex.apk` (Android 7+, ~6 MB) · [mivex.com.pl](https://mivex.com.pl)

</details>

---

<div align="center">

**Dzięki, że jesteście z nami od początku. To dopiero start. 💜**

[🌐 mivex.com.pl](https://mivex.com.pl) · [📖 README](https://github.com/mivexapp/mivex#readme) · [🐛 Zgłoś błąd](https://github.com/mivexapp/mivex/issues/new)

</div>
