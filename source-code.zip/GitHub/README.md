<div align="center">

<img src="desktop/electron/installer/icon.png" alt="Mivex" width="128" height="128">

# Mivex

### Gadaj ze swoją ekipą. *Bez szumu.*

**Komunikator dla ludzi, którzy grają, tworzą i siedzą na callu do trzeciej.**<br>
Wiadomości na żywo, serwery, rozmowy głosowe, muzyka, postacie AI i ekipa anime-maskotek, która zawsze podpowie, co gdzie jest.

[![Wersja](https://img.shields.io/badge/wersja-1.0.0-5446FF?style=for-the-badge)](https://github.com/mivexapp/mivex/releases/latest)
[![Windows](https://img.shields.io/badge/Windows-10%20%2F%2011-0078D4?style=for-the-badge&logo=windows&logoColor=white)](https://github.com/mivexapp/mivex/releases/latest)
[![Android](https://img.shields.io/badge/Android-7%2B-3DDC84?style=for-the-badge&logo=android&logoColor=white)](https://github.com/mivexapp/mivex/releases/latest)
[![Licencja](https://img.shields.io/badge/licencja-MIT-E0457B?style=for-the-badge)](LICENSE)

[![Electron](https://img.shields.io/badge/Electron-33-47848F?logo=electron&logoColor=white)](https://www.electronjs.org/)
[![Capacitor](https://img.shields.io/badge/Capacitor-8-119EFF?logo=capacitor&logoColor=white)](https://capacitorjs.com/)
[![Node.js](https://img.shields.io/badge/Node.js-22%2B-339933?logo=nodedotjs&logoColor=white)](https://nodejs.org/)
[![Języki](https://img.shields.io/badge/języki-10-F2994A)](#-języki)
[![Reklamy](https://img.shields.io/badge/reklamy%20w%20rozmowach-0-13A389)](#)

**[🌐 mivex.com.pl](https://mivex.com.pl)** &nbsp;·&nbsp;
**[⬇️ Pobierz](https://github.com/mivexapp/mivex/releases/latest)** &nbsp;·&nbsp;
**[🛠️ Zbuduj sam](#%EF%B8%8F-budowanie-ze-źródeł)** &nbsp;·&nbsp;
**[🇬🇧 English](#-english)**

</div>

---

## 📑 Spis treści

- [✨ Czym jest Mivex?](#-czym-jest-mivex)
- [📦 Co jest w tym repozytorium](#-co-jest-w-tym-repozytorium)
- [⬇️ Pobieranie](#%EF%B8%8F-pobieranie)
- [🚀 Funkcje komunikatora](#-funkcje-komunikatora)
- [🖥️ Aplikacja na Windows](#%EF%B8%8F-aplikacja-na-windows)
- [📱 Aplikacja na Androida](#-aplikacja-na-androida)
- [🏗️ Jak to działa](#%EF%B8%8F-jak-to-działa)
- [🛠️ Budowanie ze źródeł](#%EF%B8%8F-budowanie-ze-źródeł)
- [⚙️ Konfiguracja](#%EF%B8%8F-konfiguracja)
- [🔐 Bezpieczeństwo i prywatność](#-bezpieczeństwo-i-prywatność)
- [🌍 Języki](#-języki)
- [❓ Najczęstsze pytania](#-najczęstsze-pytania)
- [🤝 Współtworzenie](#-współtworzenie)
- [📜 Licencja](#-licencja)
- [🇬🇧 English](#-english)

---

## ✨ Czym jest Mivex?

**Mivex** to polski komunikator w stylu anime — coś jak Discord, ale lżejszy, bez reklam i z charakterem.
Zaczął się od jednej rzeczy, która miała działać perfekcyjnie: **rozmów ze znajomymi**. Dziś, w wersji **1.0**, ma serwery z kanałami, grupy, rozmowy głosowe, muzykę, postacie AI, sklep z diamentami i Mivex Platinum.

Mivex działa:

| | Platforma | Jak |
|:-:|---|---|
| 🌐 | **Przeglądarka** | od razu na [mivex.com.pl](https://mivex.com.pl), bez instalowania |
| 🖥️ | **Windows 10 / 11** | aplikacja `mivex-setup.exe` z własnym instalatorem |
| 📱 | **Android 7+** | aplikacja `mivex.apk` z powiadomieniami push |

> [!NOTE]
> Wszystkie trzy wersje to **to samo konto i te same rozmowy**. Piszesz na telefonie, odpisujesz na komputerze — wiadomości synchronizują się na żywo.

### 🎌 Poznaj ekipę

Mivex ma swoich anime-pomocników. Pojawiają się w aplikacji i w instalatorze, witają nowych, podpowiadają przy wiadomościach, znajomych, bezpieczeństwie i ustawieniach.

---

## 📦 Co jest w tym repozytorium

To repozytorium zawiera **kod źródłowy aplikacji klienckich Mivex** — na Windows i na Androida — tak, żeby każdy mógł je sprawdzić i **zbudować samodzielnie**.

```
mivex/
├── 📁 desktop/                     Aplikacja na Windows (Electron 33)
│   ├── electron/
│   │   ├── main.js                 punkt startowy: instalator / deinstalator / aplikacja
│   │   ├── app-main.js             okno komunikatora, powiadomienia, pobieranie, autostart
│   │   ├── activity.js             status „Gra w…” (Rich Presence + wykrywanie gier)
│   │   ├── preload.js              bezpieczny most strona ↔ aplikacja (window.mivexDesktop)
│   │   ├── prefs.js                małe ustawienia lokalne
│   │   ├── offline.html            ekran „brak połączenia”
│   │   └── installer/              własny instalator w stylu Mivex (10 języków)
│   ├── build/                      ikona i grafika startowa
│   ├── config.json                 adres serwera i rozmiar okna
│   └── package.json
│
├── 📁 android/                     Aplikacja na Androida (Capacitor 8)
│   ├── android/                    projekt Android Studio / Gradle
│   │   └── app/src/main/java/pl/mivex/app/
│   │       ├── MainActivity.java       odporność na zamknięcie silnika strony
│   │       └── MivexNativePlugin.java  wersja aplikacji, Firebase, otwieranie linków
│   ├── keystore/
│   │   └── keystore.properties.example wzór pliku z kluczem podpisu
│   ├── scripts/
│   │   ├── build-apk.js            budowanie APK jednym poleceniem
│   │   └── build-test.js           wersja testowa na Twój własny serwer
│   ├── www/                        zapasowa strona (bez internetu)
│   ├── capacitor.config.json       adres serwera, wtyczki, kolory
│   └── package.json
│
├── LICENSE
├── RELEASE_NOTES.md               opis wydania 1.0
└── README.md                      ten plik
```

> [!IMPORTANT]
> **Kod serwera (strony mivex.com.pl) nie jest częścią tego repozytorium.** Aplikacje są „oknem” na komunikator: łączą się z serwerem Mivex, a interfejs czatu przychodzi z serwera. Dzięki temu każda poprawka na serwerze trafia do wszystkich od razu — bez aktualizowania aplikacji.

---

## ⬇️ Pobieranie

Gotowe pliki znajdziesz w zakładce **[Releases](https://github.com/mivexapp/mivex/releases/latest)** albo na **[mivex.com.pl](https://mivex.com.pl)**.

| Plik | System | Rozmiar | Uwagi |
|---|---|---|---|
| 🪟 `mivex-setup.exe` | Windows 10 / 11 (64-bit) | ~72 MB | instaluje się bez uprawnień administratora |
| 🤖 `mivex.apk` | Android 7.0+ | ~6 MB | trzeba zezwolić na instalację z nieznanych źródeł |

<details>
<summary><b>🪟 Instalacja na Windows — krok po kroku</b></summary>

1. Pobierz `mivex-setup.exe`.
2. Uruchom plik. Jeśli Windows SmartScreen pokaże „System Windows ochronił komputer”, kliknij **Więcej informacji → Uruchom mimo to** (plik nie ma jeszcze płatnego certyfikatu podpisu — to normalne dla małych projektów).
3. Wybierz język i folder (domyślnie `%LOCALAPPDATA%\Programs\Mivex`).
4. Instalator utworzy skrót w menu Start (i opcjonalnie na pulpicie) oraz wpis w **Ustawienia → Aplikacje**.
5. Mivex uruchomi się sam. Zaloguj się i gotowe.

**Odinstalowanie:** *Ustawienia → Aplikacje → Mivex → Odinstaluj*. Deinstalator usuwa program, skróty i — jeśli chcesz — dane lokalne.

</details>

<details>
<summary><b>🤖 Instalacja na Androidzie — krok po kroku</b></summary>

1. Pobierz `mivex.apk` na telefon.
2. Otwórz plik. Android zapyta o zgodę na instalowanie aplikacji z tego źródła (przeglądarki / menedżera plików) — zezwól.
3. Zainstaluj i uruchom Mivex.
4. Zezwól na powiadomienia, żeby dostawać wiadomości, gdy aplikacja jest zamknięta.

**Aktualizacje:** gdy wyjdzie nowa wersja, aplikacja sama pokaże baner **„Pobierz aktualizację”**. Nowe APK instalujesz na starym — rozmowy i logowanie zostają.

</details>

---

## 🚀 Funkcje komunikatora

<table>
<tr>
<td width="50%" valign="top">

### 💬 Rozmowy
- **Wiadomości na żywo** — widzisz, kto pisze
- **Odpowiedzi, edycja, usuwanie** wiadomości
- **Formatowanie**, bloki kodu, **spoilery**
- **Reakcje** emoji jednym kliknięciem
- **Przypięte wiadomości**
- **Pliki, zdjęcia i filmy** w rozmowie
- **Grupy** ze znajomymi

</td>
<td width="50%" valign="top">

### 🏰 Serwery
- **Własne serwery** z kanałami
- **Zaproszenia** i własny link serwera
- **Wzmianki @** z powiadomieniem
- **Postacie AI** na serwerze — z własnym charakterem

</td>
</tr>
<tr>
<td valign="top">

### 🎧 Głos i muzyka
- **Rozmowy głosowe**
- **Mivex Music** — muzyka i teledyski razem ze znajomymi
- Pasek odtwarzacza, który da się zamknąć jednym **×**

</td>
<td valign="top">

### 🤖 Mivex AI
- Wbudowany asystent **Mivex AI**
- **Postacie AI** z własną osobowością
- Pomoc maskotek w aplikacji

</td>
</tr>
<tr>
<td valign="top">

### 👤 Profil z charakterem
- Awatar, **baner**, zaimki, opis, status
- **Status aktywności** — „Gra w…”, jak na Discordzie
- **Ramki awatara** i **odznaki**
- Połączenie z kontem **Discord**
- **Kilka kont** i przełączanie jednym kliknięciem

</td>
<td valign="top">

### 💎 Diamenty i Platinum
- **Diamenty** za aktywność i zadania
- **Sklep** z ramkami, odznakami i pakietami
- **Mivex Platinum** — miesiąc, 3 miesiące, rok albo **na zawsze**
- Płatność kodem **paysafecard**

</td>
</tr>
<tr>
<td valign="top">

### 🛡️ Bezpieczeństwo
- **Tylko znajomi** — nikt obcy do Ciebie nie napisze
- Kody weryfikacyjne **e-mail / SMS**
- Panel moderacji i blokady kont
- **0 reklam** w rozmowach

</td>
<td valign="top">

### 🎨 Wygląd i język
- Motyw **ciemny**, **jasny** i **AMOLED**
- **10 języków** od pierwszego dnia
- Interfejs dopasowany do telefonu i komputera

</td>
</tr>
</table>

---

## 🖥️ Aplikacja na Windows

Aplikacja na komputer to ten sam Mivex, tylko wygodniej. Zbudowana na **Electron 33**.

| Funkcja | Opis |
|---|---|
| 🧩 **Własny instalator** | jeden plik `mivex-setup.exe` działa jako instalator, aplikacja i deinstalator. Ładny kreator w stylu Mivex, 10 języków, wybór folderu, skróty, wpis w „Aplikacje i funkcje”. **Bez uprawnień administratora.** |
| 🔔 **Powiadomienia systemowe** | nowe wiadomości jako powiadomienia Windows |
| 🔴 **Licznik nieprzeczytanych** | znaczek na ikonie na pasku zadań |
| 🎮 **Status „Gra w…”** | Mivex rozpoznaje uruchomione gry i odbiera **Rich Presence** z gier i programów (ten sam kanał co Discord), a potem pokazuje to znajomym |
| 📥 **Pobieranie plików** | pliki z rozmów lądują w `Pobrane\Mivex`, z powiadomieniem po zakończeniu |
| 🚀 **Autostart** | opcjonalne uruchamianie razem z Windows (Ustawienia → Aplikacja na komputer) |
| 🎨 **Pasek okna w kolorze motywu** | przyciski okna dopasowują się do motywu ciemnego / jasnego / AMOLED |
| 📴 **Tryb offline** | bez internetu — czytelny ekran z przyciskiem „Spróbuj ponownie” zamiast pustego okna |
| 🔒 **Bezpieczny most** | strona dostaje tylko kilka ściśle określonych funkcji przez `contextBridge`; linki zewnętrzne otwierają się w przeglądarce |

<details>
<summary><b>🎮 Jak działa status aktywności?</b></summary>

1. **Rich Presence** — Mivex nasłuchuje na kanale `\\.\pipe\discord-ipc-N`, tak jak Discord. Gry i programy z Rich Presence (np. osu!, Minecraft z modami, VS Code z rozszerzeniem) wysyłają tam swój status.
2. **Wykrywanie gier** — Mivex pobiera publiczną listę gier rozpoznawanych przez Discord i co 20 sekund porównuje ją z nazwami uruchomionych programów (`tasklist`, tylko odczyt).

Funkcję można wyłączyć w ustawieniach. Mivex nie czyta zawartości okien, nie robi zrzutów ekranu i nie wysyła listy procesów na serwer — wysyła wyłącznie nazwę rozpoznanej gry.

</details>

---

## 📱 Aplikacja na Androida

Aplikacja na telefon zbudowana na **Capacitor 8** (Android 7.0+, target API 36).

| Funkcja | Opis |
|---|---|
| 🔔 **Powiadomienia push** | wiadomości przychodzą jak na Discordzie — **także gdy aplikacja jest zamknięta** (Firebase Cloud Messaging). Osobne kanały: *Wiadomości* i *Płatności* |
| 👆 **Dotknij powiadomienia** | otwiera od razu właściwą rozmowę lub kanał serwera |
| ⌨️ **Klawiatura jak należy** | pole pisania zostaje nad klawiaturą, dolne zakładki się chowają |
| 📂 **Zapis plików** | pobrane pliki trafiają do `Dokumenty/Mivex` i otwierają się jednym dotknięciem |
| 🔄 **Odporność na zawieszanie** | limity czasu zapytań, „strażnik” synchronizacji, odświeżenie po długim czasie w tle i automatyczne podniesienie się, gdy Android zamknie silnik strony |
| ⬆️ **Baner aktualizacji** | starsza wersja sama pokazuje „Pobierz aktualizację” |
| 📳 **Wibracje i przycisk Wstecz** | zachowuje się jak natywna aplikacja |
| 🎨 **Pasek stanu w kolorze Mivex** | i ekran startowy z logo |
| 📴 **Strona zapasowa** | bez internetu — ekran z przyciskiem „Spróbuj ponownie” |

**Wtyczki Capacitor:** `app`, `browser`, `filesystem`, `haptics`, `keyboard`, `local-notifications`, `push-notifications`, `splash-screen`, `status-bar`, `file-opener` oraz własna `MivexNative`.

---

## 🏗️ Jak to działa

```mermaid
flowchart LR
    subgraph Klienci
        W["🪟 Mivex na Windows<br/>Electron"]
        A["🤖 Mivex na Androida<br/>Capacitor"]
        B["🌐 Przeglądarka"]
    end
    S[("☁️ Serwer Mivex<br/>mivex.com.pl")]
    F["🔔 Firebase Cloud Messaging"]

    W -- HTTPS --> S
    A -- HTTPS --> S
    B -- HTTPS --> S
    S -- push --> F -- powiadomienie --> A
```

- Aplikacje otwierają adres serwera z `config.json` (Windows) lub `capacitor.config.json` (Android).
- Interfejs komunikatora jest serwowany przez serwer, a aplikacja dodaje to, czego przeglądarka nie potrafi: powiadomienia systemowe, licznik na pasku, status gier, zapis plików, push.
- Strona rozpoznaje aplikację po dopisku w User-Agent (`MivexAndroid/…`) lub po obiekcie `window.mivexDesktop`.

---

## 🛠️ Budowanie ze źródeł

### 📋 Wymagania

| Narzędzie | Windows | Android |
|---|:-:|:-:|
| [Node.js](https://nodejs.org/) **22 lub nowszy** | ✅ | ✅ |
| [JDK **21**](https://adoptium.net/temurin/releases/?version=21) | — | ✅ |
| [Android SDK](https://developer.android.com/studio) (platforma **API 36**, build-tools) | — | ✅ |
| System | Windows 10/11 | Windows / macOS / Linux |

> [!TIP]
> Najprościej zainstalować **Android Studio** — ma w sobie SDK i pasujące JDK. Gradle 8.14 nie działa z Javą 25, więc trzymaj się **JDK 21**.

### 🪟 Windows (Electron)

```bash
cd desktop
npm ci
```

Uruchomienie bez budowania:

```bash
npm start
```

Kreator instalatora (bez budowania pliku `.exe`):

```bash
npm run setup
```

Zbudowanie `mivex-setup.exe`:

```bash
npm run dist
```

Gotowy plik: **`desktop/dist/mivex-setup.exe`**.

| Polecenie | Co robi |
|---|---|
| `npm start` | uruchamia aplikację |
| `npm run dev` | aplikacja z narzędziami deweloperskimi |
| `npm run setup` | otwiera kreator instalatora |
| `npm run uninstall-preview` | otwiera kreator deinstalatora |
| `npm run dist` | buduje `dist/mivex-setup.exe` |

### 🤖 Android (Capacitor)

Ustaw zmienne środowiskowe (przykład dla Windows PowerShell):

```powershell
$env:JAVA_HOME = "C:\Program Files\Eclipse Adoptium\jdk-21"
$env:ANDROID_HOME = "$env:LOCALAPPDATA\Android\Sdk"
```

Linux / macOS:

```bash
export JAVA_HOME=/usr/lib/jvm/temurin-21
export ANDROID_HOME=$HOME/Android/Sdk
```

Potem:

```bash
cd android
npm ci
npm run build
```

Gotowy plik: **`android/dist/mivex.apk`**.

| Polecenie | Co robi |
|---|---|
| `npm run build` | wersja **release**, jeśli jest klucz w `keystore/`, w przeciwnym razie **debug** |
| `npm run build:debug` | zawsze wersja debug (klucz testowy, da się zainstalować) |
| `npm run build:release` | wersja release podpisana Twoim kluczem |
| `npm run build:test -- http://10.0.2.2:8090` | wersja testowa łącząca się z Twoim serwerem (np. lokalnym w emulatorze) |
| `npm run sync` | tylko `cap sync android` — przed otwarciem w Android Studio |

Projekt można też otworzyć w **Android Studio**: `npm run sync`, a potem *File → Open → `android/android`*.

### 🔑 Własny klucz podpisu

Wersja release wymaga klucza. Utwórz go raz:

```bash
keytool -genkeypair -v -keystore android/keystore/my-release.jks -alias mivex -keyalg RSA -keysize 2048 -validity 10000
```

Skopiuj `android/keystore/keystore.properties.example` jako `keystore.properties` i wpisz hasła.

> [!CAUTION]
> **Nigdy nie wrzucaj klucza ani haseł do repozytorium** (są w `.gitignore`). I nie zgub go — bez tego samego klucza nie zainstalujesz aktualizacji na starej wersji.

> [!WARNING]
> APK zbudowane przez Ciebie ma **inny podpis** niż oficjalne. Android nie pozwoli zainstalować go na oficjalnym Mivexie (i odwrotnie) — najpierw odinstaluj jedną wersję albo zmień `appId` w `capacitor.config.json` i `applicationId` w `android/app/build.gradle`.

### 🔔 Powiadomienia push we własnej wersji

Powiadomienia przy zamkniętej aplikacji idą przez **Firebase Cloud Messaging**. Plik `google-services.json` jest powiązany z projektem Firebase serwera, dlatego **nie ma go w repozytorium**.

- Bez niego aplikacja buduje się i działa normalnie — powiadomienia pokazują się, gdy aplikacja jest otwarta.
- Jeśli stawiasz **własny serwer**: utwórz projekt w [Firebase](https://console.firebase.google.com), dodaj aplikację Android o swoim `applicationId`, pobierz `google-services.json` do `android/android/app/` i zbuduj ponownie.

---

## ⚙️ Konfiguracja

### Windows — `desktop/config.json`

```json
{
  "url": "https://mivex.com.pl/app",
  "width": 1280,
  "height": 800
}
```

| Pole | Opis |
|---|---|
| `url` | adres komunikatora, który otwiera aplikacja |
| `width`, `height` | początkowy rozmiar okna |

Adres można też podmienić bez zmiany pliku zmienną `MIVEX_URL`:

```bash
MIVEX_URL=http://localhost:8090/app npm start
```

### Android — `android/capacitor.config.json`

| Pole | Opis |
|---|---|
| `appId` | identyfikator aplikacji (`pl.mivex.app`) |
| `server.url` | adres startowy (`https://mivex.com.pl/login`) |
| `server.allowNavigation` | domeny, które mogą się otworzyć w aplikacji |
| `android.appendUserAgent` | dopisek, po którym serwer rozpoznaje aplikację |
| `plugins.*` | ekran startowy, pasek stanu, klawiatura, powiadomienia |

Numer wersji: `versionCode` i `versionName` w `android/android/app/build.gradle`. **Przy każdym wydaniu zwiększ `versionCode` o 1.**

---

## 🔐 Bezpieczeństwo i prywatność

- 🔒 Cała komunikacja idzie przez **HTTPS**; aplikacja na Androida blokuje mieszane treści.
- 🧱 Aplikacja na Windows ma włączoną izolację kontekstu. Strona dostaje przez `contextBridge` tylko kilka funkcji: powiadomienie, licznik, autostart, status aktywności.
- 🎯 Uprawnienia przeglądarki są na białej liście (mikrofon/kamera do rozmów, powiadomienia, schowek, pełny ekran) — reszta jest odrzucana.
- 🌍 Linki do innych stron otwierają się w Twojej przeglądarce, nie w aplikacji.
- 🙈 W repozytorium **nie ma** żadnych kluczy, haseł, danych serwera ani plików Firebase.
- 🧑‍💻 Instalator działa **bez uprawnień administratora** i nie używa skryptów `cmd`/PowerShell.

Znalazłeś lukę? **Nie zgłaszaj jej publicznie w Issues.** Użyj prywatnego zgłoszenia: zakładka **Security → [Report a vulnerability](https://github.com/mivexapp/mivex/security/advisories/new)** — odpowiemy i podziękujemy w opisie wydania.

---

## 🌍 Języki

Mivex mówi w **10 językach** — interfejs, instalator, e-maile i powiadomienia:

| | | | | |
|:-:|:-:|:-:|:-:|:-:|
| 🇵🇱 Polski | 🇬🇧 English | 🇩🇪 Deutsch | 🇫🇷 Français | 🇪🇸 Español |
| 🇮🇹 Italiano | 🇧🇷 Português | 🇺🇦 Українська | 🇯🇵 日本語 | 🇰🇷 한국어 |

---

## ❓ Najczęstsze pytania

<details>
<summary><b>Czy Mivex jest darmowy?</b></summary>

Tak. Wszystkie podstawowe funkcje są darmowe i bez reklam. **Mivex Platinum** i pakiety diamentów to opcjonalne dodatki dla tych, którzy chcą wesprzeć projekt.

</details>

<details>
<summary><b>Dlaczego Windows ostrzega przed instalatorem?</b></summary>

SmartScreen ostrzega przed programami bez płatnego certyfikatu podpisu kodu, który kosztuje kilkaset złotych rocznie. Instalator jest zbudowany dokładnie z kodu z tego repozytorium — możesz go zbudować sam i porównać.

</details>

<details>
<summary><b>Czy mogę postawić własny serwer Mivex?</b></summary>

Kod serwera nie jest publiczny. Możesz za to zbudować aplikacje wskazujące na dowolny adres (`config.json` / `capacitor.config.json`) — przydatne np. do testów.

</details>

<details>
<summary><b>Czy jest wersja na iPhone'a, macOS albo Linuxa?</b></summary>

Na razie nie ma oficjalnej. Na iPhonie i Macu Mivex działa w przeglądarce. Electron i Capacitor obsługują te systemy, więc to kwestia przyszłych wydań — pull requesty mile widziane.

</details>

<details>
<summary><b>Zbudowałem APK i nie chce się zainstalować.</b></summary>

Najczęściej masz już zainstalowany oficjalny Mivex z innym podpisem. Odinstaluj go albo zmień `appId`. Szczegóły w sekcji [Własny klucz podpisu](#-własny-klucz-podpisu).

</details>

<details>
<summary><b>Gradle krzyczy „Unsupported class file major version”.</b></summary>

Używasz za nowej Javy. Ustaw `JAVA_HOME` na **JDK 21**.

</details>

---

## 🤝 Współtworzenie

Chętnie przyjmiemy pomoc!

1. Zrób **fork** repozytorium.
2. Utwórz gałąź: `git checkout -b poprawka/klawiatura`.
3. Wprowadź zmiany i sprawdź, czy aplikacja się buduje.
4. Otwórz **Pull Request** z opisem, co i dlaczego zmieniasz.

**Zasady:**
- Komentarze w kodzie piszemy po polsku, krótko i na temat.
- Teksty widoczne dla użytkownika muszą mieć tłumaczenie we wszystkich 10 językach.
- Żadnych kluczy, haseł ani danych osobowych w commitach.
- Błędy i pomysły zgłaszaj w zakładce **[Issues](https://github.com/mivexapp/mivex/issues)**.

---

## 📜 Licencja

Kod w tym repozytorium jest dostępny na licencji **[MIT](LICENSE)**.

Nazwa **„Mivex”**, logo oraz grafiki maskotek **nie są objęte tą licencją**. Jeśli publikujesz własną wersję lub fork, nadaj jej inną nazwę i ikonę.

---

## 🇬🇧 English

**Mivex** is an anime-styled messenger from Poland — think Discord, but lighter, ad-free and with personality. This repository contains the source code of the **Windows** (Electron 33) and **Android** (Capacitor 8) client apps, so anyone can review and build them.

> [!IMPORTANT]
> The server (mivex.com.pl) is **not** part of this repository. The apps are native shells around the web messenger: they load the server URL and add what a browser can't — system notifications, a taskbar unread badge, game activity status, file saving and push notifications.

**Features:** real-time messages, replies, edits, reactions, pins, files, groups, servers with channels and invites, voice calls, Mivex Music, Mivex AI and AI characters, rich profiles with frames and badges, game activity status, Discord account linking, multiple accounts, diamonds and Mivex Platinum, dark / light / AMOLED themes and **10 languages**.

### Build — Windows

```bash
cd desktop
npm ci
npm run dist
```

Output: `desktop/dist/mivex-setup.exe`.

### Build — Android

Requires **Node.js 22+**, **JDK 21** and **Android SDK (API 36)**. Set `JAVA_HOME` and `ANDROID_HOME`, then:

```bash
cd android
npm ci
npm run build
```

Output: `android/dist/mivex.apk` — a **release** build if `android/keystore/keystore.properties` exists (see `keystore.properties.example`), otherwise a **debug** build.

> [!WARNING]
> Self-built APKs are signed with a different key than the official app, so Android won't install one over the other. Uninstall first or change `appId`. Push notifications while the app is closed need your own `google-services.json` (Firebase) in `android/android/app/`.

**Configuration:** server URL in `desktop/config.json` (or the `MIVEX_URL` env var) and `android/capacitor.config.json`.

**Security issues:** please report privately via **Security → [Report a vulnerability](https://github.com/mivexapp/mivex/security/advisories/new)**.

**License:** code under [MIT](LICENSE). The Mivex name, logo and mascot artwork are not covered by it.

---

<div align="center">

Zrobione z 💜 w Polsce · **[mivex.com.pl](https://mivex.com.pl)**

<sub>Jeśli Mivex Ci się podoba, zostaw ⭐ — to naprawdę pomaga.</sub>

</div>
