// =========================================================
//  Mivex Desktop — punkt startowy
//  Ten sam plik .exe działa w trzech trybach:
//   • instalator   — gdy uruchomiony jako mivex-setup.exe (albo `npm run setup`)
//   • deinstalator — z parametrem --uninstall (Panel sterowania → Aplikacje)
//   • aplikacja    — zainstalowany Mivex.exe
// =========================================================
const { app } = require('electron');
const path = require('path');
const os = require('os');
// original-fs: zwykły fs Electrona traktuje app.asar jak folder — tu kopiujemy go jako plik
const fs = require('original-fs');

const isSetup = !!process.env.PORTABLE_EXECUTABLE_FILE || process.argv.includes('--setup');
const isUninstall = process.argv.includes('--uninstall');
const fromArg = process.argv.find((a) => a.startsWith('--uninstall-from='));
const TEMP_PREFIX = 'MivexUninstall-';

/** Sprzątanie po poprzednim deinstalatorze (kopia w %TEMP%), bez cmd/skryptów — zwykłe usuwanie plików. */
function cleanOldUninstallers() {
  try {
    for (const name of fs.readdirSync(os.tmpdir())) {
      if (!name.startsWith(TEMP_PREFIX)) continue;
      const dir = path.join(os.tmpdir(), name);
      if (path.dirname(process.execPath) === dir) continue;
      try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) { /* jeszcze w użyciu */ }
    }
  } catch (e) { /* brak dostępu do %TEMP% */ }
}

function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name);
    const d = path.join(dest, entry.name);
    if (entry.isDirectory()) copyDir(s, d);
    else fs.copyFileSync(s, d);
  }
}

if (isUninstall && !fromArg && app.isPackaged) {
  // Program nie może skasować pliku, z którego właśnie działa. Zamiast sztuczek z cmd
  // (których nie lubią antywirusy) deinstalator kopiuje się do %TEMP% i stamtąd usuwa Mivex.
  const installDir = path.dirname(process.execPath);
  const temp = path.join(os.tmpdir(), TEMP_PREFIX + Date.now());
  // Nie udało się skopiować albo uruchomić kopii — deinstalacja na miejscu (pliki programu zostaną do ręcznego usunięcia)
  const inPlace = () => require('./installer/installer-main').run({ mode: 'uninstall', dryRun: false, from: installDir });
  try {
    copyDir(installDir, temp);
    const child = require('child_process').spawn(path.join(temp, path.basename(process.execPath)),
      ['--uninstall', '--uninstall-from=' + installDir], { detached: true, stdio: 'ignore', cwd: temp });
    // Czekamy, aż kopia naprawdę wystartuje (np. antywirus mógł ją zablokować) — dopiero wtedy wychodzimy
    child.once('spawn', () => { child.unref(); app.exit(0); });
    child.once('error', inPlace);
  } catch (e) {
    inPlace();
  }
} else if (isSetup || isUninstall) {
  cleanOldUninstallers();
  require('./installer/installer-main').run({
    mode: isUninstall ? 'uninstall' : 'install',
    dryRun: !app.isPackaged, // w trybie deweloperskim nic nie kopiujemy — tylko podgląd
    from: fromArg ? fromArg.slice('--uninstall-from='.length) : null,
  });
} else {
  cleanOldUninstallers();
  require('./app-main').run();
}
