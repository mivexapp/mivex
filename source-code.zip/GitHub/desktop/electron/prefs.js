// Mivex Desktop — małe ustawienia lokalne (%APPDATA%\Mivex\mivex.json)
const { app } = require('electron');
const fs = require('fs');
const path = require('path');

const file = () => path.join(app.getPath('userData'), 'mivex.json');

exports.read = () => {
  try { return JSON.parse(fs.readFileSync(file(), 'utf8')); } catch (e) { return {}; }
};

exports.write = (patch) => {
  const data = Object.assign(exports.read(), patch);
  fs.mkdirSync(path.dirname(file()), { recursive: true });
  fs.writeFileSync(file(), JSON.stringify(data, null, 2));
  return data;
};
