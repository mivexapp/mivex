// =========================================================
//  Mivex Desktop — status aktywności („Gra w…”) jak na Discordzie
//
//  1) Rich Presence: Mivex nasłuchuje na tym samym kanale IPC co Discord
//     (\\.\pipe\discord-ipc-N). Gry i aplikacje z Rich Presence (np. Minecraft z modami,
//     osu!, VS Code z rozszerzeniem) wysyłają tu swój status — dokładnie jak do Discorda.
//     Gdy Discord też działa, aplikacje łączą się do niego (pierwszy wolny kanał) — wtedy
//     Mivex korzysta z wykrywania gier (punkt 2).
//  2) Wykrywanie gier: lista gier, które rozpoznaje Discord (applications/detectable),
//     porównywana co 20 s z nazwami uruchomionych programów (tasklist, tylko odczyt).
// =========================================================
const net = require('net');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { app, net: enet } = require('electron');

const API = 'https://discord.com/api/v10';
const SCAN_MS = 20000;

let onChange = () => {};
let enabled = true;
let current = null;            // aktualnie wysyłana aktywność
const rpc = new Map();          // połączenie → { appId, activity, at }
let detected = null;            // gra wykryta po procesach
let detectable = null;          // Map: exe → { id, name, icon }
let scanTimer = null;
let server = null;
const appInfo = new Map();      // appId → { name, icon, assets: Map(nazwa → id) }

// --- Pomocnicze ---
function fetchJson(url) {
  return new Promise((resolve) => {
    try {
      const req = enet.request({ url, method: 'GET' });
      let body = '';
      req.on('response', (res) => {
        res.on('data', (c) => { body += c; });
        res.on('end', () => { try { resolve(res.statusCode < 300 ? JSON.parse(body) : null); } catch (e) { resolve(null); } });
      });
      req.on('error', () => resolve(null));
      req.end();
    } catch (e) { resolve(null); }
  });
}

/** Nazwa, ikona i obrazki aplikacji Discorda (cache). */
async function getApp(appId) {
  if (!appId || !/^\d{5,25}$/.test(appId)) return null;
  if (appInfo.has(appId)) return appInfo.get(appId);
  const info = { name: null, icon: null, assets: new Map() };
  appInfo.set(appId, info);
  const rpcData = await fetchJson(`${API}/applications/${appId}/rpc`);
  if (rpcData) { info.name = rpcData.name || null; info.icon = rpcData.icon || null; }
  const assets = await fetchJson(`${API}/oauth2/applications/${appId}/assets`);
  if (Array.isArray(assets)) assets.forEach((a) => info.assets.set(String(a.name), String(a.id)));
  return info;
}

/** Klucz obrazka z Rich Presence → adres (mp:external/…, adres https albo nazwa zasobu aplikacji). */
function imageUrl(appId, info, key) {
  if (!key || typeof key !== 'string') return null;
  if (key.startsWith('mp:')) return 'https://media.discordapp.net/' + key.slice(3);
  if (/^https:\/\//.test(key)) return key;
  if (/^\d+$/.test(key)) return `https://cdn.discordapp.com/app-assets/${appId}/${key}.png`;
  const id = info && info.assets.get(key);
  return id ? `https://cdn.discordapp.com/app-assets/${appId}/${id}.png` : null;
}

// --- Wybór aktywności do pokazania: Rich Presence ma pierwszeństwo przed wykrytą grą ---
function recompute() {
  let best = null;
  rpc.forEach((c) => { if (c.activity && (!best || c.at > best.at)) best = c; });
  const next = !enabled ? null : (best ? best.activity : detected);
  if (JSON.stringify(next) !== JSON.stringify(current)) {
    current = next;
    onChange(current);
  }
}

// =======================================================
//  1) Rich Presence — serwer IPC zgodny z Discordem
// =======================================================
const OP = { HANDSHAKE: 0, FRAME: 1, CLOSE: 2, PING: 3, PONG: 4 };

function encode(op, data) {
  const json = Buffer.from(JSON.stringify(data), 'utf8');
  const head = Buffer.alloc(8);
  head.writeInt32LE(op, 0);
  head.writeInt32LE(json.length, 4);
  return Buffer.concat([head, json]);
}

function handleConnection(sock) {
  const conn = { appId: null, activity: null, at: 0 };
  rpc.set(sock, conn);
  let buf = Buffer.alloc(0);
  const send = (op, data) => { try { sock.write(encode(op, data)); } catch (e) { /* zamknięte */ } };

  sock.on('data', async (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 8) {
      const op = buf.readInt32LE(0);
      const len = buf.readInt32LE(4);
      if (len < 0 || len > 1024 * 1024) { sock.destroy(); return; }
      if (buf.length < 8 + len) break;
      let msg = {};
      try { msg = JSON.parse(buf.slice(8, 8 + len).toString('utf8')); } catch (e) { /* */ }
      buf = buf.slice(8 + len);

      if (op === OP.HANDSHAKE) {
        conn.appId = String(msg.client_id || '');
        send(OP.FRAME, {
          cmd: 'DISPATCH', evt: 'READY', nonce: null,
          data: { v: 1, config: { cdn_host: 'cdn.discordapp.com', api_endpoint: '//discord.com/api', environment: 'production' },
            user: { id: '0', username: 'Mivex', discriminator: '0', global_name: 'Mivex', avatar: null, bot: false, flags: 0, premium_type: 0 } },
        });
        getApp(conn.appId);
      } else if (op === OP.FRAME) {
        if (msg.cmd === 'SET_ACTIVITY') {
          const a = msg.args && msg.args.activity;
          conn.activity = a ? await toActivity(conn.appId, a) : null;
          conn.at = Date.now();
          recompute();
          send(OP.FRAME, { cmd: 'SET_ACTIVITY', data: a || null, evt: null, nonce: msg.nonce || null });
        } else {
          // SUBSCRIBE, itp. — potwierdzamy, żeby biblioteki RPC nie zgłaszały błędów
          send(OP.FRAME, { cmd: msg.cmd, data: {}, evt: null, nonce: msg.nonce || null });
        }
      } else if (op === OP.PING) {
        send(OP.PONG, msg);
      } else if (op === OP.CLOSE) {
        sock.end();
      }
    }
  });
  const drop = () => { rpc.delete(sock); recompute(); };
  sock.on('close', drop);
  sock.on('error', drop);
}

/** Aktywność z Rich Presence w formacie Mivex (to samo co pokazuje Discord). */
async function toActivity(appId, a) {
  const info = await getApp(appId);
  const assets = a.assets || {};
  const ts = a.timestamps || {};
  const name = (info && info.name) || a.name || 'Gra';
  const types = { 0: 'playing', 1: 'streaming', 2: 'listening', 3: 'watching', 5: 'competing' };
  return {
    type: types[a.type] || 'playing',
    name: String(name).slice(0, 128),
    details: String(a.details || '').slice(0, 128),
    state: String(a.state || '').slice(0, 128) + (a.party && a.party.size ? ` (${a.party.size[0]} z ${a.party.size[1]})` : ''),
    start: ts.start ? (ts.start < 1e12 ? ts.start * 1000 : ts.start) : Date.now(),
    large_image: imageUrl(appId, info, assets.large_image) || (info && info.icon ? `https://cdn.discordapp.com/app-icons/${appId}/${info.icon}.png` : null),
    small_image: imageUrl(appId, info, assets.small_image),
    app_id: appId || null,
    source: 'rpc',
  };
}

/** Zajmujemy pierwszy wolny kanał discord-ipc-0…9 (Windows: named pipe, inne systemy: gniazdo w katalogu tymczasowym). */
function startRpc(i = 0) {
  if (i > 9) return;
  const name = process.platform === 'win32'
    ? `\\\\?\\pipe\\discord-ipc-${i}`
    : path.join(process.env.XDG_RUNTIME_DIR || process.env.TMPDIR || '/tmp', `discord-ipc-${i}`);
  const probe = net.createConnection(name);
  probe.on('connect', () => { probe.destroy(); startRpc(i + 1); });   // zajęte (np. przez Discorda)
  probe.on('error', () => {
    if (process.platform !== 'win32') { try { fs.unlinkSync(name); } catch (e) { /* */ } }
    server = net.createServer(handleConnection);
    server.on('error', () => { server = null; startRpc(i + 1); });
    server.listen(name);
  });
}

// =======================================================
//  2) Wykrywanie gier po procesach
// =======================================================
async function loadDetectable() {
  const file = path.join(app.getPath('userData'), 'detectable.json');
  let list = null;
  try {
    const st = fs.statSync(file);
    if (Date.now() - st.mtimeMs < 3 * 86400000) list = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) { /* brak cache */ }
  if (!list) {
    const fresh = await fetchJson(`${API}/applications/detectable`);
    if (Array.isArray(fresh)) {
      // Zapisujemy tylko to, czego potrzebujemy (pełna lista ma kilka MB)
      list = fresh.map((g) => ({ id: g.id, name: g.name, icon: g.icon || null,
        exe: (g.executables || []).filter((e) => e.os === 'win32' && !e.is_launcher).map((e) => String(e.name).toLowerCase()) }))
        .filter((g) => g.exe.length);
      try { fs.writeFileSync(file, JSON.stringify(list)); } catch (e) { /* */ }
    }
  }
  detectable = new Map();
  (list || []).forEach((g) => g.exe.forEach((e) => {
    const base = e.split('/').pop();
    if (base && !detectable.has(base)) detectable.set(base, g);
  }));
}

const started = new Map(); // id gry → kiedy ją zobaczyliśmy

function scan() {
  if (!enabled || !detectable || process.platform !== 'win32') return;
  execFile('tasklist', ['/fo', 'csv', '/nh'], { windowsHide: true, maxBuffer: 8 * 1024 * 1024 }, (err, out) => {
    if (err) return;
    let found = null;
    const seen = new Set();
    for (const line of String(out).split(/\r?\n/)) {
      const m = line.match(/^"([^"]+)"/);
      if (!m) continue;
      const exe = m[1].toLowerCase();
      const g = detectable.get(exe);
      if (g) { seen.add(g.id); if (!found) found = g; }
    }
    started.forEach((_, id) => { if (!seen.has(id)) started.delete(id); });
    if (found && !started.has(found.id)) started.set(found.id, Date.now());
    detected = found ? {
      type: 'playing', name: found.name, details: '', state: '', start: started.get(found.id),
      large_image: found.icon ? `https://cdn.discordapp.com/app-icons/${found.id}/${found.icon}.png` : null,
      small_image: null, app_id: found.id, source: 'detect',
    } : null;
    recompute();
  });
}

exports.start = (cb, on) => {
  onChange = cb;
  enabled = on !== false;
  startRpc();
  loadDetectable().then(() => { scan(); scanTimer = setInterval(scan, SCAN_MS); });
};
exports.setEnabled = (on) => { enabled = !!on; recompute(); if (enabled) scan(); };
exports.current = () => current;
exports.stop = () => { clearInterval(scanTimer); if (server) server.close(); };
