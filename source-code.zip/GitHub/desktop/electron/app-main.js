// =========================================================
//  Mivex Desktop — tryb aplikacji
//  Otwiera stronę Mivex (config.json → url). Niezalogowany → strona sama
//  przekierowuje na /login, zalogowany → od razu komunikator (/app).
// =========================================================
const { app, BrowserWindow, shell, ipcMain, Notification, nativeImage, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const prefs = require('./prefs');
const activity = require('./activity');

const config = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'config.json'), 'utf8'));
const APP_URL = process.env.MIVEX_URL || config.url;
const APP_ORIGIN = new URL(APP_URL).origin;
const isDev = process.argv.includes('--dev');

let win = null;

function iconImage() {
  const p = path.join(__dirname, 'installer', 'icon.png');
  return fs.existsSync(p) ? nativeImage.createFromPath(p) : undefined;
}

/** Adres startowy — przy pierwszym uruchomieniu dokleja język wybrany w instalatorze. */
function startUrl() {
  const p = prefs.read();
  if (p.lang && !p.langSent) {
    prefs.write({ langSent: true });
    const u = new URL(APP_URL);
    u.searchParams.set('lang', p.lang);
    return u.href;
  }
  return APP_URL;
}

function createWindow() {
  win = new BrowserWindow({
    width: config.width || 1280,
    height: config.height || 800,
    minWidth: 940,
    minHeight: 600,
    show: false,
    title: 'Mivex',
    icon: iconImage(),
    backgroundColor: '#0a0916',
    titleBarStyle: 'hidden',
    titleBarOverlay: process.platform === 'darwin' ? true : { color: '#0a0916', symbolColor: '#aeaacf', height: 30 },
    trafficLightPosition: { x: 10, y: 8 },
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: true,
    },
  });

  Menu.setApplicationMenu(isDev ? Menu.getApplicationMenu() : null);

  win.once('ready-to-show', () => win.show());
  win.loadURL(startUrl());

  // Brak połączenia → strona offline z ponowieniem
  win.webContents.on('did-fail-load', (_e, code, desc, url, isMainFrame) => {
    if (!isMainFrame || code === -3) return; // -3 = przerwane (np. przekierowanie)
    win.loadFile(path.join(__dirname, 'offline.html'), { query: { url: APP_URL, error: desc } });
  });

  // Linki zewnętrzne otwieramy w przeglądarce
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (url.startsWith('file:')) return;
    if (new URL(url).origin !== APP_ORIGIN) {
      e.preventDefault();
      shell.openExternal(url);
    }
  });

  setupSession(win.webContents.session);

  win.on('focus', () => win.flashFrame(false));
  win.on('closed', () => { win = null; });

  if (isDev) win.webContents.openDevTools({ mode: 'detach' });
}

// --- Uprawnienia (mikrofon do rozmów, powiadomienia) i pobieranie plików ---
const DOWNLOADED = {
  pl: 'Pobrano', 'en-GB': 'Downloaded', de: 'Heruntergeladen', fr: 'Téléchargé', es: 'Descargado',
  it: 'Scaricato', 'pt-BR': 'Baixado', uk: 'Завантажено', ja: 'ダウンロード完了', ko: '다운로드 완료',
};
const ALLOWED = ['media', 'notifications', 'clipboard-sanitized-write', 'speaker-selection', 'fullscreen'];

const fromApp = (url) => { try { return new URL(url).origin === APP_ORIGIN; } catch (e) { return false; } };

/** Pliki z czatu zapisują się w Pobrane/Mivex (bez okna „Zapisz jako”), a nazwy się nie nadpisują. */
function downloadsDir() {
  const dir = path.join(app.getPath('downloads'), 'Mivex');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function freeName(dir, name) {
  const safe = name.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').slice(0, 180) || 'plik';
  const ext = path.extname(safe);
  const base = safe.slice(0, safe.length - ext.length);
  let candidate = safe;
  for (let i = 1; fs.existsSync(path.join(dir, candidate)); i++) candidate = `${base} (${i})${ext}`;
  return path.join(dir, candidate);
}

function setupSession(ses) {
  ses.setPermissionRequestHandler((wc, permission, callback, details) => {
    callback(ALLOWED.includes(permission) && fromApp(details.requestingUrl || wc.getURL()));
  });
  ses.setPermissionCheckHandler((wc, permission, origin) => ALLOWED.includes(permission) && fromApp(origin));

  ses.on('will-download', (_e, item) => {
    const target = freeName(downloadsDir(), item.getFilename());
    item.setSavePath(target);
    item.once('done', (_ev, state) => {
      if (state !== 'completed' || !Notification.isSupported()) return;
      const lang = prefs.read().lang || 'pl';
      const n = new Notification({ title: DOWNLOADED[lang] || DOWNLOADED.pl, body: path.basename(target), icon: iconImage(), silent: true });
      n.on('click', () => shell.showItemInFolder(target));
      n.show();
    });
  });
}

ipcMain.on('mivex:open-downloads', () => shell.openPath(downloadsDir()));

// --- Komunikacja ze stroną (preload.js) ---
ipcMain.on('mivex:notify', (_e, { title, body }) => {
  if (!win || (win.isFocused() && win.isVisible())) return;
  if (Notification.isSupported()) {
    const n = new Notification({ title: String(title).slice(0, 100), body: String(body).slice(0, 200), icon: iconImage(), silent: true });
    n.on('click', () => { win.show(); win.focus(); });
    n.show();
  }
  win.flashFrame(true);
});

ipcMain.on('mivex:badge', (_e, count) => {
  const n = Math.max(0, parseInt(count, 10) || 0);
  if (process.platform === 'darwin' || process.platform === 'linux') app.setBadgeCount(n);
  if (win) win.setTitle(n ? `(${n}) Mivex` : 'Mivex');
});

// Kolory przycisków okna dopasowane do motywu strony
ipcMain.on('mivex:titlebar', (_e, { color, symbolColor }) => {
  if (!win || process.platform === 'darwin') return;
  const hex = /^#[0-9a-f]{6}$/i;
  if (hex.test(color) && hex.test(symbolColor)) {
    try { win.setTitleBarOverlay({ color, symbolColor, height: 30 }); } catch (e) { /* starszy system */ }
  }
});

ipcMain.on('mivex:retry', () => {
  if (win) win.loadURL(APP_URL);
});

// --- Uruchamianie razem z Windows (ten sam wpis co w instalatorze: nazwa „Mivex”) ---
const loginItem = () => ({ path: process.execPath, args: [], name: 'Mivex' });

function getAutostart() {
  try { return app.getLoginItemSettings(loginItem()).openAtLogin; } catch (e) { return false; }
}

function setAutostart(on) {
  if (!app.isPackaged) return false; // wersja deweloperska nie dopisuje się do autostartu
  try { app.setLoginItemSettings(Object.assign({ openAtLogin: !!on }, loginItem())); } catch (e) { /* */ }
  prefs.write({ autostartInit: true });
  return getAutostart();
}

ipcMain.handle('mivex:autostart-get', () => getAutostart());
ipcMain.handle('mivex:autostart-set', (_e, on) => setAutostart(on));

// --- Status aktywności („Gra w…”, Rich Presence) ---
const activityOn = () => prefs.read().activity !== false;
ipcMain.handle('mivex:activity-get', () => ({ enabled: activityOn(), current: activity.current() }));
ipcMain.handle('mivex:activity-set', (_e, on) => {
  prefs.write({ activity: !!on });
  activity.setEnabled(!!on);
  return !!on;
});

/** Domyślnie włączone: przy pierwszym uruchomieniu (bez wyboru w instalatorze) Mivex dopisuje się do autostartu. */
function initAutostart() {
  const p = prefs.read();
  if (!app.isPackaged || p.autostartInit) return;
  // Tylko zainstalowany Mivex (z folderu zapisanego przez instalator) — kopia uruchomiona z innego miejsca nie przejmie autostartu
  if (!p.installDir || path.resolve(p.installDir).toLowerCase() !== path.dirname(process.execPath).toLowerCase()) return;
  setAutostart(true);
}

exports.run = () => {
  // Strona rozpoznaje aplikację po tym dopisku (pomija stronę startową)
  app.userAgentFallback = `${app.userAgentFallback} MivexDesktop/${app.getVersion()}`;
  if (process.platform === 'win32') app.setAppUserModelId('app.mivex.desktop');

  // --quit-for-update: instalator/deinstalator prosi działający Mivex o zamknięcie (zamiast zabijać proces)
  const quitRequest = process.argv.includes('--quit-for-update');
  if (!app.requestSingleInstanceLock()) {
    app.quit();
    return;
  }
  if (quitRequest) { app.quit(); return; } // nic nie działało — nie otwieramy okna
  app.on('second-instance', (_e, argv) => {
    if (argv.includes('--quit-for-update')) {
      app.quit();
      return;
    }
    if (win) {
      if (win.isMinimized()) win.restore();
      win.show();
      win.focus();
    }
  });

  app.whenReady().then(() => {
    initAutostart();
    createWindow();
    activity.start((a) => { if (win && !win.isDestroyed()) win.webContents.send('mivex:activity', a); }, activityOn());
    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
  });

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
  });
  app.on('will-quit', () => activity.stop());
};
