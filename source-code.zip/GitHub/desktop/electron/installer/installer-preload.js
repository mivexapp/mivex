// Mivex — most instalator (HTML) ↔ proces główny
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('setup', {
  close: () => ipcRenderer.send('setup:close'),
  minimize: () => ipcRenderer.send('setup:minimize'),
  pickDir: (current) => ipcRenderer.invoke('setup:pick-dir', current),
  install: (opts) => ipcRenderer.invoke('setup:install', opts),
  launch: (dir) => ipcRenderer.send('setup:launch', dir),
  uninstall: (opts) => ipcRenderer.invoke('setup:uninstall', opts),
  finishUninstall: () => ipcRenderer.send('setup:finish-uninstall'),
  onProgress: (cb) => ipcRenderer.on('setup:progress', (_e, data) => cb(data)),
});
