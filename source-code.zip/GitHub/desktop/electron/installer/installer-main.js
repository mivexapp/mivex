// =========================================================
//  Mivex — własny instalator / deinstalator (Windows)
//  mivex-setup.exe rozpakowuje się do %TEMP% i uruchamia ten tryb.
//  Instalator kopiuje rozpakowaną aplikację do wybranego folderu,
//  tworzy skróty i wpis w "Aplikacje i funkcje", a potem uruchamia Mivex.
// =========================================================
const { app, BrowserWindow, ipcMain, dialog, shell, nativeImage } = require('electron');
const path = require('path');
const os = require('os');
// original-fs: zwykły fs Electrona traktuje app.asar jak folder — instalator musi go kopiować jako plik
const fs = require('original-fs');
const { execFile, spawn } = require('child_process');
const prefs = require('../prefs');

const PRODUCT = 'Mivex';
const EXE_NAME = 'Mivex.exe';
const UNINSTALL_KEY = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Mivex';

let win = null;
let opts = { mode: 'install', dryRun: false, from: null };
let realUserData = null;   // dane aplikacji (%APPDATA%\Mivex) — przy deinstalacji działamy na kopii, żeby dało się je usunąć
let savedLang = null;

// --- Pomocnicze ---

const defaultDir = () => path.join(process.env.LOCALAPPDATA || app.getPath('appData'), 'Programs', PRODUCT);
const startMenuLink = () => path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', `${PRODUCT}.lnk`);
const desktopLink = () => path.join(app.getPath('desktop'), `${PRODUCT}.lnk`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function guessLang() {
  const saved = savedLang || prefs.read().lang;
  if (saved) return saved;
  const loc = (app.getLocale() || 'en').toLowerCase();
  const map = { pl: 'pl', de: 'de', fr: 'fr', es: 'es', it: 'it', pt: 'pt-BR', uk: 'uk', ja: 'ja', ko: 'ko' };
  return map[loc.slice(0, 2)] || 'en-GB';
}

function run(cmd, args) {
  return new Promise((resolve) => {
    execFile(cmd, args, { windowsHide: true }, (err, stdout) => resolve({ ok: !err, out: stdout || '' }));
  });
}

const regAdd = (key, name, type, value) => run('reg', ['add', key, '/v', name, '/t', type, '/d', String(value), '/f']);

/**
 * Prosi działający Mivex z danego folderu, żeby sam się zamknął (--quit-for-update).
 * Bez zabijania procesów — jeśli stara wersja nie posłucha, kopiowanie zgłosi błąd
 * i okno poprosi o zamknięcie Mivex ręcznie.
 */
async function closeRunning(dir) {
  const exe = path.join(dir, EXE_NAME);
  if (!fs.existsSync(exe) || path.resolve(exe).toLowerCase() === path.resolve(process.execPath).toLowerCase()) return;
  // Czy Mivex w ogóle działa? Działający .exe jest zablokowany do zapisu — wtedy dopiero prosimy go o zamknięcie
  // (inaczej uruchomilibyśmy niepotrzebnie starą wersję aplikacji).
  try { fs.closeSync(fs.openSync(exe, 'r+')); return; } catch (e) { /* zajęty = działa */ }
  try {
    spawn(exe, ['--quit-for-update'], { detached: true, stdio: 'ignore', cwd: dir, env: cleanEnv() }).unref();
  } catch (e) { return; }
  await sleep(1500);
}

/** Autostart z Windows przez wbudowaną funkcję Electrona (tak jak robi to np. Discord). */
function setAutostart(on, exe) {
  try { app.setLoginItemSettings({ openAtLogin: !!on, path: exe, args: [], name: PRODUCT }); } catch (e) { /* */ }
}

function listFiles(dir, base = dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) listFiles(full, base, out);
    else out.push({ rel: path.relative(base, full), size: fs.statSync(full).size });
  }
  return out;
}

/** Folder instalacji zawsze kończy się na \Mivex — dzięki temu deinstalator nie skasuje niczego innego. */
function normalizeDir(dir) {
  dir = path.resolve(dir || defaultDir());
  return path.basename(dir).toLowerCase() === PRODUCT.toLowerCase() ? dir : path.join(dir, PRODUCT);
}

function cleanEnv() {
  const env = Object.assign({}, process.env);
  Object.keys(env).filter((k) => k.startsWith('PORTABLE_EXECUTABLE')).forEach((k) => delete env[k]);
  return env;
}

const send = (data) => { if (win && !win.isDestroyed()) win.webContents.send('setup:progress', data); };

// --- Instalacja ---

async function install({ dir, desktop, autostart, lang }) {
  const dest = normalizeDir(dir);
  prefs.write({ lang, langSent: false });

  if (opts.dryRun) {
    for (let i = 0; i <= 100; i += 2) { send({ percent: i, file: `resources\\app.asar (${i}%)` }); await sleep(45); }
    return { ok: true, dir: dest, dry: true };
  }

  const src = path.dirname(process.execPath);
  await closeRunning(dest);

  const files = listFiles(src);
  const total = files.reduce((a, f) => a + f.size, 0) || 1;
  let done = 0;
  let lastSent = 0;
  for (const f of files) {
    const target = path.join(dest, f.rel);
    await fs.promises.mkdir(path.dirname(target), { recursive: true });
    // Plik zajęty (Mivex jeszcze działa) — kilka prób, potem czytelny błąd w oknie
    for (let attempt = 0; ; attempt++) {
      try { await fs.promises.copyFile(path.join(src, f.rel), target); break; } catch (e) {
        if (attempt >= 5 || !['EBUSY', 'EPERM', 'EACCES'].includes(e.code)) throw e;
        await sleep(700);
      }
    }
    done += f.size;
    const now = Date.now();
    if (now - lastSent > 60) { lastSent = now; send({ percent: Math.round((done / total) * 96), file: f.rel }); }
  }

  const exe = path.join(dest, EXE_NAME);
  send({ percent: 97, file: 'shortcuts' });

  // Skróty (menu Start zawsze, pulpit opcjonalnie)
  const link = { target: exe, cwd: dest, icon: exe, iconIndex: 0, appUserModelId: 'app.mivex.desktop', description: 'Mivex' };
  fs.mkdirSync(path.dirname(startMenuLink()), { recursive: true });
  shell.writeShortcutLink(startMenuLink(), 'create', link);
  if (desktop) shell.writeShortcutLink(desktopLink(), 'create', link);
  else if (fs.existsSync(desktopLink())) fs.unlinkSync(desktopLink());

  // Wpis w "Aplikacje i funkcje" (odinstalowanie)
  send({ percent: 98, file: 'registry' });
  await regAdd(UNINSTALL_KEY, 'DisplayName', 'REG_SZ', PRODUCT);
  await regAdd(UNINSTALL_KEY, 'DisplayVersion', 'REG_SZ', app.getVersion());
  await regAdd(UNINSTALL_KEY, 'Publisher', 'REG_SZ', PRODUCT);
  await regAdd(UNINSTALL_KEY, 'DisplayIcon', 'REG_SZ', `"${exe}",0`);
  await regAdd(UNINSTALL_KEY, 'InstallLocation', 'REG_SZ', dest);
  await regAdd(UNINSTALL_KEY, 'UninstallString', 'REG_SZ', `"${exe}" --uninstall`);
  await regAdd(UNINSTALL_KEY, 'EstimatedSize', 'REG_DWORD', Math.round(total / 1024));
  await regAdd(UNINSTALL_KEY, 'NoModify', 'REG_DWORD', 1);
  await regAdd(UNINSTALL_KEY, 'NoRepair', 'REG_DWORD', 1);

  // Autostart z Windows
  setAutostart(autostart, exe);
  prefs.write({ autostartInit: true }); // wybór z instalatora — aplikacja go nie nadpisze

  prefs.write({ installDir: dest });
  send({ percent: 100, file: '' });
  return { ok: true, dir: dest };
}

function launch(dir) {
  if (opts.dryRun) { app.quit(); return; }
  const exe = path.join(normalizeDir(dir), EXE_NAME);
  if (fs.existsSync(exe)) {
    spawn(exe, [], { detached: true, stdio: 'ignore', env: cleanEnv(), cwd: path.dirname(exe) }).unref();
  }
  setTimeout(() => app.quit(), 300);
}

// --- Deinstalacja ---

/** Folder do usunięcia: przekazany przez kopię w %TEMP% albo (awaryjnie) folder, z którego działamy. */
const targetDir = () => path.resolve(opts.from || path.dirname(process.execPath));

/** Bezpieczne usuwanie — tylko folder kończący się na \Mivex z Mivex.exe w środku. */
function removeProgramDir(dir) {
  if (path.basename(dir).toLowerCase() !== PRODUCT.toLowerCase() || !fs.existsSync(path.join(dir, EXE_NAME))) return false;
  // Nigdy nie kasujemy plików, z których sami działamy (to psuło okno deinstalatora)
  if (path.resolve(dir).toLowerCase() === path.dirname(process.execPath).toLowerCase()) return false;
  try { fs.rmSync(dir, { recursive: true, force: true, maxRetries: 5, retryDelay: 400 }); return true; } catch (e) { return false; }
}

async function uninstall({ removeData }) {
  const dir = targetDir();
  if (opts.dryRun) {
    for (let i = 0; i <= 100; i += 4) { send({ percent: i }); await sleep(40); }
    return { ok: true, dry: true };
  }
  send({ percent: 10 });
  await closeRunning(dir);
  send({ percent: 30 });
  for (const l of [startMenuLink(), desktopLink()]) {
    try { if (fs.existsSync(l)) fs.unlinkSync(l); } catch (e) { /* skrót w użyciu */ }
  }
  setAutostart(false, path.join(dir, EXE_NAME));
  send({ percent: 45 });
  await run('reg', ['delete', UNINSTALL_KEY, '/f']);
  send({ percent: 60 });
  // Pliki programu: deinstalator działa z kopii w %TEMP%, więc może je usunąć od razu
  removeProgramDir(dir);
  send({ percent: 85 });
  if (removeData && realUserData && path.basename(realUserData).toLowerCase() === PRODUCT.toLowerCase()) {
    try { fs.rmSync(realUserData, { recursive: true, force: true, maxRetries: 3, retryDelay: 300 }); } catch (e) { /* */ }
  }
  send({ percent: 100 });
  return { ok: true };
}

/**
 * Koniec deinstalacji: najpierw chowamy okno (użytkownik od razu widzi, że się zamknęło),
 * potem ostatnia próba sprzątania i twarde wyjście — app.quit() potrafił zawisnąć z pustym oknem,
 * gdy pliki programu zniknęły spod działającego procesu.
 */
function finishUninstall() {
  if (win && !win.isDestroyed()) win.hide();
  setTimeout(() => {
    if (!opts.dryRun) removeProgramDir(targetDir());
    app.exit(0);
  }, 50);
}

// --- Okno ---

function createWindow() {
  const iconPath = path.join(__dirname, 'icon.png');
  win = new BrowserWindow({
    width: 900,
    height: 560,
    resizable: false,
    maximizable: false,
    fullscreenable: false,
    frame: false,
    show: false,
    title: opts.mode === 'uninstall' ? 'Mivex — odinstalowanie' : 'Mivex — instalacja',
    backgroundColor: '#0a0916',
    icon: fs.existsSync(iconPath) ? nativeImage.createFromPath(iconPath) : undefined,
    webPreferences: {
      preload: path.join(__dirname, 'installer-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  win.setMenu(null);
  win.once('ready-to-show', () => win.show());
  win.loadFile(path.join(__dirname, 'installer.html'), {
    query: {
      mode: opts.mode,
      lang: guessLang(),
      dir: opts.mode === 'uninstall' ? targetDir() : (prefs.read().installDir || defaultDir()),
      version: app.getVersion(),
      dry: opts.dryRun ? '1' : '',
    },
  });
}

function registerIpc() {
  ipcMain.on('setup:close', () => {
    if (opts.mode === 'uninstall') { if (win && !win.isDestroyed()) win.hide(); setTimeout(() => app.exit(0), 50); } else app.quit();
  });
  ipcMain.on('setup:minimize', () => win && win.minimize());
  ipcMain.handle('setup:pick-dir', async (_e, current) => {
    const r = await dialog.showOpenDialog(win, { defaultPath: current, properties: ['openDirectory', 'createDirectory'] });
    return r.canceled || !r.filePaths[0] ? null : normalizeDir(r.filePaths[0]);
  });
  ipcMain.handle('setup:install', async (_e, o) => {
    try { return await install(o); } catch (e) { return { ok: false, error: e.message }; }
  });
  ipcMain.on('setup:launch', (_e, dir) => launch(dir));
  ipcMain.handle('setup:uninstall', async (_e, o) => {
    try { return await uninstall(o); } catch (e) { return { ok: false, error: e.message }; }
  });
  ipcMain.on('setup:finish-uninstall', () => finishUninstall());
}

exports.run = (o) => {
  opts = Object.assign(opts, o);
  if (opts.mode === 'uninstall' && !opts.dryRun) {
    // Deinstalator trzyma swoje pliki sesji osobno — wtedy %APPDATA%\Mivex nie jest zajęty i da się go usunąć
    realUserData = app.getPath('userData');
    savedLang = prefs.read().lang || null;
    app.setPath('userData', path.join(os.tmpdir(), 'MivexUninstallData'));
    // Bez procesu GPU — nie potrzebuje bibliotek z folderu programu, który właśnie usuwamy
    if (!app.isReady()) app.disableHardwareAcceleration();
  }
  if (process.platform === 'win32') app.setAppUserModelId('app.mivex.setup');
  registerIpc();
  app.whenReady().then(createWindow);
  app.on('window-all-closed', () => app.quit());
};
