// Mivex — instalator: ekrany, języki, postęp
(() => {
  const $ = (s) => document.querySelector(s);
  const q = new URLSearchParams(location.search);
  const mode = q.get('mode') || 'install';
  const api = window.setup || mockApi();

  const LANGS = window.SETUP_LANGS;
  const FLAGS = window.SETUP_FLAGS;
  const T = window.SETUP_T;

  const MASCOT_IMG = { welcome: 'miko.png', installing: 'kaito.png', done: 'miko.png', error: 'riku.png', uninstall: 'yuki.png', removing: 'yuki.png', removed: 'kaito.png' };

  let lang = T[q.get('lang')] ? q.get('lang') : 'pl';
  let dir = q.get('dir') || '';
  let screen = mode === 'uninstall' ? 'uninstall' : 'welcome';
  let tipTimer = null;

  function tr() { return T[lang]; }

  function renderTexts() {
    document.documentElement.lang = lang;
    document.title = mode === 'uninstall' ? tr().un_bar : tr().title;
    $('#barTitle').textContent = document.title;
    document.querySelectorAll('[data-t]').forEach((el) => { el.textContent = tr()[el.dataset.t] || ''; });
    renderGuide();
  }

  function renderGuide() {
    const key = screen === 'removing' ? 'uninstall' : screen;
    const [name, text] = tr().say[key] || tr().say.welcome;
    $('#guideName').textContent = name;
    $('#guideText').textContent = text;
    const img = $('#guideImg');
    const src = MASCOT_IMG[screen] || 'miko.png';
    if (!img.src.endsWith(src)) {
      img.style.opacity = 0;
      setTimeout(() => { img.src = src; img.style.opacity = 1; }, 150);
    }
  }

  function show(name) {
    screen = name;
    document.querySelectorAll('.screen').forEach((s) => s.classList.toggle('active', s.dataset.screen === name));
    renderGuide();
  }

  function renderLangs() {
    $('#langs').innerHTML = Object.entries(LANGS).map(([code, label]) =>
      `<button type="button" class="lang${code === lang ? ' on' : ''}" data-lang="${code}"><svg class="flag" width="24" height="16" viewBox="0 0 30 20">${FLAGS[code]}</svg>${label}</button>`).join('');
  }

  // --- Pasek okna ---
  $('#btnClose').onclick = () => { if (screen !== 'installing' && screen !== 'removing') api.close(); };
  $('#btnMin').onclick = () => api.minimize();

  // --- Powitanie ---
  $('#versionTag').textContent = 'v' + (q.get('version') || '');
  $('#dirText').textContent = dir;
  $('#unDir').textContent = dir;
  $('#dryTag').hidden = q.get('dry') !== '1';

  $('#langs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-lang]');
    if (!b) return;
    lang = b.dataset.lang;
    renderLangs(); renderTexts();
  });
  const setOptions = (open) => { $('#options').hidden = !open; };
  $('#toggleOptions').onclick = () => setOptions(true);
  $('#optionsDone').onclick = () => setOptions(false);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setOptions(false); });
  $('#pickDir').onclick = async () => {
    const d = await api.pickDir(dir);
    if (d) { dir = d; $('#dirText').textContent = d; }
  };

  // --- Instalacja ---
  api.onProgress((p) => {
    const pct = Math.max(0, Math.min(100, p.percent | 0));
    if (screen === 'removing') { $('#unBar').style.width = pct + '%'; return; }
    $('#bar').style.width = pct + '%';
    $('#percentText').textContent = pct + '%';
    if (p.file) $('#fileText').textContent = p.file;
  });

  function rotateTips() {
    let i = 0;
    const next = () => { $('#tip').textContent = tr().tips[i++ % tr().tips.length]; };
    next();
    tipTimer = setInterval(next, 3500);
  }

  async function doInstall() {
    show('installing');
    $('#bar').style.width = '0%';
    rotateTips();
    const r = await api.install({ dir, lang, desktop: $('#optDesktop').checked, autostart: $('#optAutostart').checked });
    clearInterval(tipTimer);
    if (r && r.ok) {
      dir = r.dir || dir;
      setTimeout(() => show('done'), 350);
    } else {
      $('#errText').textContent = (r && r.error) || '';
      show('error');
    }
  }
  $('#btnInstall').onclick = doInstall;
  $('#btnRetry').onclick = doInstall;
  $('#btnQuit').onclick = () => api.close();
  $('#btnFinish').onclick = () => { if ($('#optLaunch').checked) api.launch(dir); else api.close(); };

  // --- Deinstalacja ---
  $('#btnCancel').onclick = () => api.close();
  $('#btnUninstall').onclick = async () => {
    show('removing');
    const r = await api.uninstall({ removeData: $('#optRemoveData').checked });
    if (r && r.ok) { show('removed'); autoClose(); }
    else { $('#errText').textContent = (r && r.error) || ''; show('error'); }
  };
  // Po odinstalowaniu okno zamyka się samo po kilku sekundach (albo od razu po kliknięciu)
  let closing = false;
  const finish = () => { if (closing) return; closing = true; api.finishUninstall(); };
  function autoClose() {
    let n = 5;
    const btn = $('#btnUnFinish');
    const tick = () => {
      btn.textContent = `${tr().close} (${n})`;
      if (n-- <= 0) finish(); else setTimeout(tick, 1000);
    };
    tick();
  }
  $('#btnUnFinish').onclick = finish;

  // Podgląd w zwykłej przeglądarce (bez Electron)
  function mockApi() {
    let cb = () => {};
    return {
      close() {}, minimize() {}, launch() {}, finishUninstall() {},
      pickDir: async () => null,
      onProgress: (f) => { cb = f; },
      install: () => new Promise((res) => { let p = 0; const t = setInterval(() => { p += 4; cb({ percent: p, file: 'resources\\app.asar' }); if (p >= 100) { clearInterval(t); res({ ok: true }); } }, 60); }),
      uninstall: () => new Promise((res) => { let p = 0; const t = setInterval(() => { p += 10; cb({ percent: p }); if (p >= 100) { clearInterval(t); res({ ok: true }); } }, 60); }),
    };
  }

  renderLangs();
  renderTexts();
  show(screen);
})();
