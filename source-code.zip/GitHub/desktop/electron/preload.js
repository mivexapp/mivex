// =========================================================
//  Mivex Desktop — preload (bezpieczny most strona ↔ Electron)
//  Strona widzi obiekt window.mivexDesktop.
// =========================================================
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('mivexDesktop', {
  platform: process.platform,
  notify: (title, body) => ipcRenderer.send('mivex:notify', { title, body }),
  setBadge: (count) => ipcRenderer.send('mivex:badge', count),
  retry: () => ipcRenderer.send('mivex:retry'),
  openDownloads: () => ipcRenderer.send('mivex:open-downloads'),
  // Uruchamianie razem z Windows (Ustawienia → Powiadomienia → Aplikacja na komputer)
  getAutostart: () => ipcRenderer.invoke('mivex:autostart-get'),
  setAutostart: (on) => ipcRenderer.invoke('mivex:autostart-set', !!on),
  // Status „Gra w…” (wykryte gry + Rich Presence jak w Discordzie)
  getActivity: () => ipcRenderer.invoke('mivex:activity-get'),
  setActivityEnabled: (on) => ipcRenderer.invoke('mivex:activity-set', !!on),
  onActivity: (cb) => ipcRenderer.on('mivex:activity', (_e, a) => cb(a)),
});

// Kolor paska okna (przyciski zamknij/minimalizuj) zgodny z motywem strony
function syncTitleBar() {
  const css = getComputedStyle(document.documentElement);
  const toHex = (v) => {
    v = v.trim();
    if (/^#[0-9a-f]{6}$/i.test(v)) return v;
    const m = v.match(/^#([0-9a-f])([0-9a-f])([0-9a-f])$/i);
    return m ? `#${m[1]}${m[1]}${m[2]}${m[2]}${m[3]}${m[3]}` : null;
  };
  const color = toHex(css.getPropertyValue('--bg-0'));
  const symbolColor = toHex(css.getPropertyValue('--text-2'));
  if (color && symbolColor) ipcRenderer.send('mivex:titlebar', { color, symbolColor });
}

window.addEventListener('DOMContentLoaded', () => {
  document.documentElement.classList.add('is-desktop', 'platform-' + process.platform);
  syncTitleBar();
  new MutationObserver(syncTitleBar).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
});
