package pl.mivex.app;

import android.os.Bundle;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.WebViewListener;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(MivexNativePlugin.class);
        super.onCreate(savedInstanceState);

        // Android zamknął silnik strony (mało pamięci w tle) — zamiast białego ekranu / zamknięcia aplikacji
        // uruchamiamy ekran od nowa (wcześniej trzeba było ręcznie restartować aplikację).
        if (getBridge() != null) {
            getBridge().addWebViewListener(new WebViewListener() {
                @Override
                public boolean onRenderProcessGone(WebView webView, RenderProcessGoneDetail detail) {
                    runOnUiThread(MainActivity.this::recreate);
                    return true;
                }
            });
        }
    }
}
