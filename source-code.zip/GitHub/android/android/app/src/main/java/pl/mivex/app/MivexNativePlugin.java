package pl.mivex.app;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Mivex — informacje o aplikacji dla strony (android.js):
 * wersja (baner „Pobierz aktualizację”) i czy aplikacja ma Firebase (powiadomienia push przy zamkniętej aplikacji).
 */
@CapacitorPlugin(name = "MivexNative")
public class MivexNativePlugin extends Plugin {

    @PluginMethod
    public void info(PluginCall call) {
        JSObject r = new JSObject();
        try {
            PackageInfo pi = getContext().getPackageManager().getPackageInfo(getContext().getPackageName(), 0);
            r.put("versionName", pi.versionName);
            r.put("versionCode", (int) (android.os.Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode));
        } catch (Exception e) {
            r.put("versionCode", 0);
        }
        // Wtyczka google-services tworzy zasób google_app_id tylko wtedy, gdy przy budowaniu był plik google-services.json.
        // Bez niego rejestracja push zamknęłaby aplikację — dlatego strona najpierw o to pyta.
        int id = getContext().getResources().getIdentifier("google_app_id", "string", getContext().getPackageName());
        r.put("firebase", id != 0);
        call.resolve(r);
    }

    /** Otwiera adres w przeglądarce telefonu (np. pobranie nowej wersji APK). */
    @PluginMethod
    public void openUrl(PluginCall call) {
        String url = call.getString("url", "");
        if (url == null || !url.startsWith("https://")) {
            call.reject("url");
            return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }
}
