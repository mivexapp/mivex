// Buduje aplikację Mivex na Androida → android/dist/mivex.apk
//
// Wymaga JDK 21 i Android SDK (API 36). Ścieżki bierze z JAVA_HOME i ANDROID_HOME
// (albo ANDROID_SDK_ROOT). Bez nich Gradle użyje tego, co jest w PATH / local.properties.
//
// Podpis:
//  • jest keystore/keystore.properties → wersja release podpisana Twoim kluczem,
//  • brak → wersja debug (podpisana kluczem testowym, też da się zainstalować).
// Wymuszenie: node scripts/build-apk.js --debug   albo   --release
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const androidDir = path.join(root, 'android');
const env = Object.assign({}, process.env);
const sdk = env.ANDROID_HOME || env.ANDROID_SDK_ROOT;
if (env.JAVA_HOME) env.PATH = path.join(env.JAVA_HOME, 'bin') + path.delimiter + env.PATH;

const run = (cmd, cwd) => execSync(cmd, { cwd: cwd || root, env, stdio: 'inherit' });

// Ścieżka do SDK dla Gradle (local.properties nie trafia do repozytorium)
if (sdk) fs.writeFileSync(path.join(androidDir, 'local.properties'), 'sdk.dir=' + sdk.replace(/\\/g, '\\\\') + '\n');
else if (!fs.existsSync(path.join(androidDir, 'local.properties'))) {
  console.error('Nie znam ścieżki do Android SDK — ustaw ANDROID_HOME (np. C:\\Android\\sdk albo ~/Android/Sdk).');
  process.exit(1);
}

const hasKey = fs.existsSync(path.join(root, 'keystore', 'keystore.properties'));
const release = process.argv.includes('--release') || (hasKey && !process.argv.includes('--debug'));
if (release && !hasKey) {
  console.error('Brak keystore/keystore.properties — skopiuj keystore.properties.example i uzupełnij (README → „Własny klucz podpisu”).');
  process.exit(1);
}
const variant = release ? 'release' : 'debug';
const task = release ? 'assembleRelease' : 'assembleDebug';

run('npx cap sync android');
run((process.platform === 'win32' ? '.\\gradlew.bat ' : './gradlew ') + task + ' --no-daemon', androidDir);

const apk = path.join(androidDir, 'app', 'build', 'outputs', 'apk', variant, 'app-' + variant + '.apk');
const dest = path.join(root, 'dist', 'mivex.apk');
fs.mkdirSync(path.dirname(dest), { recursive: true });
fs.copyFileSync(apk, dest);
console.log('Gotowe (' + variant + '): ' + dest + ' (' + (fs.statSync(dest).size / 1048576).toFixed(1) + ' MB)');
