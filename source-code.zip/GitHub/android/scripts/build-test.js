// Wersja testowa (debug) łącząca się z Twoim serwerem zamiast mivex.com.pl — np. lokalnym w emulatorze.
// Użycie: node scripts/build-test.js http://10.0.2.2:8090
// Po zbudowaniu capacitor.config.json wraca do mivex.com.pl.
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const base = (process.argv[2] || 'http://10.0.2.2:8090').replace(/\/$/, '');
const root = path.resolve(__dirname, '..');
const androidDir = path.join(root, 'android');
const env = Object.assign({}, process.env);
const sdk = env.ANDROID_HOME || env.ANDROID_SDK_ROOT;
if (env.JAVA_HOME) env.PATH = path.join(env.JAVA_HOME, 'bin') + path.delimiter + env.PATH;
if (sdk) fs.writeFileSync(path.join(androidDir, 'local.properties'), 'sdk.dir=' + sdk.replace(/\\/g, '\\\\') + '\n');

const cfgFile = path.join(root, 'capacitor.config.json');
const original = fs.readFileSync(cfgFile, 'utf8');
const run = (cmd, cwd) => execSync(cmd, { cwd: cwd || root, env, stdio: 'inherit' });

try {
  const cfg = JSON.parse(original);
  cfg.server.url = base + '/login';
  cfg.server.cleartext = base.startsWith('http:');
  cfg.server.allowNavigation = [new URL(base).hostname];
  cfg.android.allowMixedContent = cfg.server.cleartext;
  fs.writeFileSync(cfgFile, JSON.stringify(cfg, null, 2));
  run('npx cap sync android');
  run((process.platform === 'win32' ? '.\\gradlew.bat' : './gradlew') + ' assembleDebug --no-daemon', androidDir);
  console.log('Test APK: ' + path.join(androidDir, 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk'));
} finally {
  fs.writeFileSync(cfgFile, original);
  run('npx cap sync android');
}
